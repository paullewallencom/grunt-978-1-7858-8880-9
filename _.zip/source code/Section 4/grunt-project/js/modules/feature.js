﻿define(function () {
    'use strict';

    // a simple module
    return {
        version: '0.1.0'
    };
});
