﻿define(function () {
    'use strict';

    return {
        log: function (input) {
            console.log(input);
        }
    };
});
