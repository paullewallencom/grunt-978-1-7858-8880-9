﻿require(['modules/logger'], function (logger) {
    'use strict';

    logger.log('RequireJS configured and working!');
});
