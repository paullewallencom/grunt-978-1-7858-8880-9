﻿// some file

var someVariable;
