﻿// some file
var global = 'something';
