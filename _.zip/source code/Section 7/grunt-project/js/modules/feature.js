﻿define(function () {
    'use strict';

    return {
        version: '0.1.0'
    };
});
