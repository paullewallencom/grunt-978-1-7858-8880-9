﻿var fs = require('fs');

module.exports = function (grunt) {
    'use strict';

    // config
    grunt.initConfig({
        pkg: grunt.file.readJSON('package.json'),
        running: {
            taskOwner: ' Dan',
            src: 'js/somefile.js',
            dest: 'someProcessedFile.js',
            options: {
                comment: '/* <%= pkg.author %> */\n'
            }
        },
        multi: {
            config1: {
                message: 'This is config1',
                files: {
                    'someOtherProcessedFile.js': 'js/somefile.js'
                }
            },
            config2: {
                message: 'This is config2',
                files: [
                    {
                        src: 'js/somefile.js',
                        dest: 'oneLastProcessedFile.js'
                    }
                ]
            }
        },
        prop: 'Some property'
    });

    // custom task
    grunt.registerTask('running', 'An example task', function (arg1) {
        var done = this.async(),
            comment = this.options().comment;

        grunt.config.requires('running.taskOwner');

        grunt.log.writeln('grunt running...', this.name, grunt.config.get('running.taskOwner'));

        fs.readFile(grunt.config.get('running.src'), function (err, data) {
            fs.writeFile(grunt.config.get('running.dest'), comment + data);
            done();
        });

    });

    // alias task
    grunt.registerTask('run', 'Run all the tasks', ['running']);

    // multitask
    grunt.registerMultiTask('multi', 'An example multitask', function (arg1) {
        grunt.log.writeln(this.data.message, arg1);

        this.files.forEach(function (file) {
            console.log(file.src[0] + ' ' + file.dest);
        });
    });
}
