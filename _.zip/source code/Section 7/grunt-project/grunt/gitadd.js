﻿module.exports = function (grunt) {
    'use strict';

    var config = {
        dist: {
            options: {
                all: true
            }
        }
    }

    grunt.config('gitadd', config);
}
