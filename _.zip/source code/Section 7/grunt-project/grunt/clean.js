﻿module.exports = function (grunt) {
    'use strict';

    var config = ['dist/**/*'];

    grunt.config('clean', config);
}
